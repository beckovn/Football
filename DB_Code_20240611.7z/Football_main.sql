create table countries
(id number primary key not null,
 cname varchar2(100) unique not null,
 continent varchar(50),
 create_date date default sysdate,
 change_date date default sysdate);
 
create SEQUENCE countries_seq start with 1 increment by 1 MAXVALUE 12000000;

create table tournaments
(id number primary key not null,
 tname varchar2(100) not null,
 country_id number,
 create_date date default sysdate,
 change_date date default sysdate,
 constraint tourn_country_fk foreign key(country_id) references countries(id));
 
create SEQUENCE tournaments_seq start with 1 increment by 1 MAXVALUE 120000000000;

create table teams
(id number primary key not null,
 tname varchar2(100) unique not null,
 country_id number,
 create_date date default sysdate,
 change_date date default sysdate,
 constraint team_country_fk foreign key(country_id) references countries(id));
 
create SEQUENCE teams_seq start with 1 increment by 1 MAXVALUE 12000000000000;

create table load_data
(data_load_id number primary key not null,
 country_id number,
 load_values varchar2(4000),
 constraint load_data_country_fk foreign key(country_id) references countries(id));
 
create SEQUENCE load_data_seq start with 1 increment by 1 MAXVALUE 12000000000000;

alter table load_data add load_status VARCHAR2(20) default 'NOT LOADED' not null ;

create table tournament_teams
(team_id number,
 tournament_id number,
 create_date date default sysdate,
 change_date date default sysdate,
 constraint tt_fk1 foreign key(team_id) references teams(id),
 constraint tt_fk2 foreign key(tournament_id) references tournaments(id));

create index TT_TEAM_IDX on tournament_teams(team_id);
create index TT_TOURN_IDX on tournament_teams(tournament_id);

alter table tournament_teams add (id number primary key not null);

create SEQUENCE tournament_teams_seq start with 1 increment by 1 MAXVALUE 12000000000000 NOCACHE ;
alter sequence teams_seq nocache;
alter sequence load_data_seq nocache;
alter sequence tournaments_seq nocache;
alter sequence countries_seq nocache;

alter table tournament_teams add constraint TT_UK unique(team_id, tournament_id);

create table matches
(id number primary key not null,
 tournament_id number,
 home_team_id number,
 away_team_id number,
 match_played_date date,
 match_round varchar2(100),
 create_date date default sysdate,
 change_date date default sysdate,
 constraint FK_MATCH_TOURN_FK foreign key(tournament_id) references tournaments(id),
 constraint FK_MATCH_TEAM_FK foreign key(home_team_id) references teams(id),
 constraint FK_MATCH_TEAM_FK2 foreign key(away_team_id) references teams(id));
 
comment on column matches.create_date is 'Date of record creation';
create SEQUENCE matches_seq start with 1 increment by 1 MAXVALUE 120000000000000000 NOCACHE ;
comment on column matches.id is 'matches_seq';
alter table matches add home_team_goals number;
alter table matches add away_team_goals number;
alter table matches add bookkeeper_result_1X2 varchar2(1);
alter table matches add constraint bkr_1X2_check check (bookkeeper_result_1X2 in ('1','X','2'));
comment on column matches.bookkeeper_result_1X2 is 'Only 1,X,2 as values';
alter table matches add bookkeeper_result_other varchar2(200);

alter table load_data add load_type number;
comment on column load_data.load_type is '1 - loading teams; 2 - loading matches; 3 - matches to come';
update load_data set load_type = 1;

alter table load_data MODIFY (load_type not null);
alter table load_data add tournament_id number;
alter table load_data add constraint LD_T_FK foreign key (tournament_id)
references tournaments(id);
create index LD_TOURN_IDX on load_data(tournament_id);

alter table load_data add create_data date default sysdate;

create table betting_koef
(match_id number primary key not null,
 koef_1 number,
 koef_X number,
 koef_2 number,
 koef_over_2 number,
 koef_under_2 number,
 constraint bet_koef_fk foreign key(match_id) references matches(id));

alter table tournaments
add finished varchar2(1) default 'N';

alter table betting_koef add create_date date default sysdate;

create index MTEAMS_IDX on matches(home_team_id);
create index MTEAMS2_IDX on matches(away_team_id);

create table predictions
(match_id number,
 prediction_1x2 varchar2(1),
 over_under_pred varchar2(50),
 pred_algorithm_version varchar2(50),
 prediction_1x2_tf varchar2(1),
 over_under_pred_tf varchar2(1),
 constraint PRED_MATCHES_FK foreign key(match_id) references matches(id));
 
create table rankings
(id number primary key,
 tournament_id number not null,
 team_id number not null,
 position number,
 points number,
 constraint rank_tourn_fk
 foreign key (tournament_id)
 references tournaments(id),
 constraint rank_teams_fk
 foreign key (team_id)
 references teams(id));
 
alter table rankings
add constraint rank_uk
unique(tournament_id, team_id);

alter table rankings
add constraint rank_uk_2
unique(tournament_id, position);
 
create SEQUENCE rankings_seq start with 1 increment by 1 MAXVALUE 12000000000000;

alter table rankings
add (goals_scored number, goals_received number, goal_diff number);

alter table rankings
add constraint rank_check_diff
check (goal_diff = goals_scored - goals_received);

-- ways to handle ORA-28002: the password will expire within days
alter user football identified by football;

-- better:
select name from v$database; --result: XE
select profile from dba_users where username = 'FOOTBALL'; -- result: DEFAULT
alter profile default limit password_life_time unlimited;

alter table rankings add dp_flag varchar2(1);
comment on COLUMN rankings.dp_flag IS 'D - drop out; P - promotion to upper league';

alter table predictions add creation_date date default sysdate;

create table predictions_log
as
select * from predictions where 1=2;

create table predictions_ver2
as
select * from predictions where 1=2;

COMMENT ON COLUMN predictions.over_under_pred 
   IS 'O - over 2.5; U - under 2.5;';
   
alter table predictions_log add log_date date default sysdate;